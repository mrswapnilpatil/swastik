I.Theme

Bistro, Copyright 2015 
Bistro is licensed under GNU General Public License V2 or later. You can find a copy of it in the license.txt file.

Bistro is:
- a child theme of Sydney (http://wordpress.org/themes/sydney/)
- built to work with the Restaurant plugin by Justin Tadlock (http://wordpress.org/plugins/restaurant/)

II. Resources

b) Images folder
b1) Image 1 (also used in screenshot)
Copyright: pmvchamara
Resource URI: http://pixabay.com/en/pizza-plate-food-italian-dinner-705061/
License: CC0 1.0
License URI: http://creativecommons.org/publicdomain/zero/1.0/deed.en
b2) Image 2
Copyright: olafBroeker
Resource URI: http://pixabay.com/en/kitchen-eat-food-cook-cooking-pan-515388/
License: CC0 1.0
License URI: http://creativecommons.org/publicdomain/zero/1.0/deed.en
b3) Image 3
Copyright: Unsplash
Resource URI: http://pixabay.com/en/kitchen-work-restaurant-cook-chef-731351/
License: CC0 1.0
License URI: http://creativecommons.org/publicdomain/zero/1.0/deed.en

III. Documentation 

Theme documentation is available on http://athemes.com/documentation/bistro/